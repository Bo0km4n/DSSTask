#ifndef CAPTHREAD_H
#define CAPTHREAD_H

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void capitalize(void *str);
#endif
