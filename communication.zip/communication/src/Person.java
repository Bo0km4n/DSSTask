import java.io.Serializable;

public class Person implements Serializable {
	private static final long serialVersionUID = 0x1122334455667788L;
	public String name = "Jobs";
}
